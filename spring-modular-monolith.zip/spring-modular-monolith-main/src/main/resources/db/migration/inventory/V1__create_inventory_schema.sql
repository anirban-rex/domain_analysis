CREATE SCHEMA inventory;
